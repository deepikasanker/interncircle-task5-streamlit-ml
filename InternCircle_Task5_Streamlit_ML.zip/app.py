import streamlit as st
import joblib
import numpy as np

st.set_page_config(page_title="Iris ML Predictor", page_icon="🌸")

@st.cache_resource
def load_model():
    return joblib.load("iris_model.joblib")

model = load_model()

st.title("🌸 Iris Flower ML Predictor")
st.write("Enter the flower measurements using the sliders below.")

sepal_length = st.slider("Sepal Length (cm)", 4.0, 8.0, 5.1, 0.1)
sepal_width = st.slider("Sepal Width (cm)", 2.0, 4.5, 3.5, 0.1)
petal_length = st.slider("Petal Length (cm)", 1.0, 7.0, 1.4, 0.1)
petal_width = st.slider("Petal Width (cm)", 0.1, 2.5, 0.2, 0.1)

if st.button("Predict"):
    features = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    prediction = int(model.predict(features)[0])
    classes = ["Setosa", "Versicolor", "Virginica"]

    st.success(f"Predicted Iris Species: **{classes[prediction]}**")

    probabilities = model.predict_proba(features)[0]
    st.subheader("Prediction Probabilities")
    for name, probability in zip(classes, probabilities):
        st.write(f"{name}: {probability:.2%}")
