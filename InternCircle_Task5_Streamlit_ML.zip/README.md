# Streamlit / Gradio Interactive ML Web App

## Project
Iris Flower Classification using a Random Forest ML model and Streamlit.

## Features
- Streamlit interface
- Model loading with joblib
- Interactive input sliders
- Real-time prediction
- Prediction probabilities

## Run locally
1. Install Python.
2. Open a terminal in this folder.
3. Run: pip install -r requirements.txt
4. Run: streamlit run app.py

## Submission
Submit the project ZIP/file(s) through the InternCircle "Submit Task" button for Task 5.
If the portal asks for a live/demo URL, deploy the app first (for example using Streamlit Community Cloud) and submit that URL along with the project files.
